// Main Application Logic

const API_BASE = '/api';

// API Helper Functions
async function apiCall(endpoint, options = {}) {
    try {
        const response = await fetch(`${API_BASE}${endpoint}`, {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message || 'API request failed');
        }

        return data;
    } catch (error) {
        console.error('API Error:', error);
        showNotification(error.message, 'danger');
        throw error;
    }
}

// Notification System
function showNotification(message, type = 'info') {
    const container = document.getElementById('notificationContainer') || createNotificationContainer();

    const notification = document.createElement('div');
    notification.className = `alert alert-${type}`;
    notification.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 9999; min-width: 300px; animation: slideInRight 0.3s ease;';
    notification.textContent = message;

    container.appendChild(notification);

    setTimeout(() => {
        notification.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

function createNotificationContainer() {
    const container = document.createElement('div');
    container.id = 'notificationContainer';
    document.body.appendChild(container);
    return container;
}

// Navigation
function initNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('.section');

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetSection = link.getAttribute('data-section');

            // Update active nav link
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');

            // Show target section
            sections.forEach(s => s.classList.remove('active'));
            document.getElementById(targetSection).classList.add('active');

            // Load section data
            loadSectionData(targetSection);
        });
    });

    // Load initial section
    const initialSection = 'dashboard';
    document.querySelector(`[data-section="${initialSection}"]`).click();
}

async function loadSectionData(section) {
    switch (section) {
        case 'dashboard':
            await loadDashboard();
            break;
        case 'students':
            await loadStudents();
            break;
        case 'attendance':
            await loadAttendance();
            break;
        case 'performance':
            await loadPerformance();
            break;
    }
}

// Dashboard
async function loadDashboard() {
    try {
        const [studentsData, attendanceStats] = await Promise.all([
            apiCall('/students'),
            apiCall('/attendance/stats')
        ]);

        const totalStudents = studentsData.count || 0;
        const criticalAttendance = attendanceStats.criticalCount || 0;

        document.getElementById('totalStudentsCount').textContent = totalStudents;
        document.getElementById('criticalAttendanceCount').textContent = criticalAttendance;

        // Update critical students list
        const criticalList = document.getElementById('criticalStudentsList');
        if (attendanceStats.criticalStudents && attendanceStats.criticalStudents.length > 0) {
            criticalList.innerHTML = attendanceStats.criticalStudents.map(student => `
        <div class="card" style="padding: 1rem; margin-bottom: 0.5rem;">
          <div class="flex-between">
            <div>
              <strong>${student.name}</strong> (${student.rollNumber})
            </div>
            <span class="badge badge-danger">${student.attendancePercentage}%</span>
          </div>
        </div>
      `).join('');
        } else {
            criticalList.innerHTML = '<div class="empty-state"><p>No students with critical attendance</p></div>';
        }
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

// Initialize Application
async function initApp() {
    // Load translations
    await i18n.loadTranslations(i18n.getCurrentLanguage());
    i18n.updatePageContent();

    // Setup language selector
    const languageSelector = document.getElementById('languageSelector');
    const languages = i18n.getSupportedLanguages();

    languageSelector.innerHTML = Object.entries(languages).map(([code, name]) =>
        `<option value="${code}" ${code === i18n.getCurrentLanguage() ? 'selected' : ''}>${name}</option>`
    ).join('');

    languageSelector.addEventListener('change', async (e) => {
        await i18n.loadTranslations(e.target.value);
        i18n.updatePageContent();
        // Reload current section
        const activeSection = document.querySelector('.section.active').id;
        await loadSectionData(activeSection);
    });

    // Setup theme toggle
    document.getElementById('themeToggle').addEventListener('click', () => {
        themeManager.toggleTheme();
    });

    // Initialize navigation
    initNavigation();

    // Initialize modules
    initStudentsModule();
    initAttendanceModule();
    initPerformanceModule();
}

// Start app when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
} else {
    initApp();
}

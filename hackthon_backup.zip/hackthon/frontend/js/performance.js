// Performance Module

let performanceCache = [];

async function loadPerformance() {
    try {
        const [studentsData, performanceData] = await Promise.all([
            apiCall('/students'),
            apiCall('/performance')
        ]);

        studentsCache = studentsData.data || [];
        performanceCache = performanceData.data || [];

        renderPerformanceList();
        populatePerformanceStudentSelect();
    } catch (error) {
        console.error('Error loading performance:', error);
    }
}

function renderPerformanceList() {
    const container = document.getElementById('performanceList');

    if (performanceCache.length === 0) {
        container.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">📈</div>
        <div class="empty-state-text">${i18n.t('common.noData')}</div>
        <button class="btn btn-primary" onclick="showAddPerformanceModal()">
          ${i18n.t('performance.addPerformance')}
        </button>
      </div>
    `;
        return;
    }

    // Group by student
    const byStudent = {};
    performanceCache.forEach(perf => {
        if (!byStudent[perf.studentId]) {
            const student = studentsCache.find(s => s.id === perf.studentId);
            byStudent[perf.studentId] = {
                student: student || { name: 'Unknown', rollNumber: '-' },
                records: []
            };
        }
        byStudent[perf.studentId].records.push(perf);
    });

    container.innerHTML = Object.values(byStudent).map(data => {
        const avgMarks = data.records.reduce((sum, r) => sum + r.marks, 0) / data.records.length;

        return `
      <div class="card">
        <div class="card-header">
          <div>
            <h3 style="margin: 0;">${data.student.name}</h3>
            <p style="margin: 0; color: var(--text-secondary);">${data.student.rollNumber}</p>
          </div>
          <div>
            <span class="badge ${avgMarks >= 75 ? 'badge-success' : avgMarks >= 60 ? 'badge-warning' : 'badge-danger'}">
              Avg: ${avgMarks.toFixed(1)}%
            </span>
          </div>
        </div>
        <div class="card-body">
          <div class="table-container">
            <table class="table">
              <thead>
                <tr>
                  <th>${i18n.t('performance.subject')}</th>
                  <th>${i18n.t('performance.marks')}</th>
                  <th>${i18n.t('performance.category')}</th>
                  <th>${i18n.t('performance.aiRemarks')}</th>
                </tr>
              </thead>
              <tbody>
                ${data.records.map(record => `
                  <tr>
                    <td><strong>${record.subject}</strong></td>
                    <td>${record.marks}/${record.maxMarks || 100}</td>
                    <td><span class="badge ${getCategoryBadge(record.category)}">${record.category}</span></td>
                    <td>${record.remarks}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
    }).join('');
}

function getCategoryBadge(category) {
    if (category === 'Excellent') return 'badge-success';
    if (category === 'Good') return 'badge-info';
    if (category === 'Average') return 'badge-warning';
    return 'badge-danger';
}

function populatePerformanceStudentSelect() {
    const select = document.getElementById('performanceStudentSelect');
    if (!select) return;

    select.innerHTML = `
    <option value="">${i18n.t('attendance.selectStudent')}</option>
    ${studentsCache.map(student =>
        `<option value="${student.id}">${student.name} (${student.rollNumber})</option>`
    ).join('')}
  `;
}

function showAddPerformanceModal() {
    const modal = document.getElementById('performanceModal');
    document.getElementById('performanceForm').reset();

    // Set today's date
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('examDate').value = today;

    // Populate student select in modal
    const modalSelect = document.getElementById('performanceModalStudentSelect');
    modalSelect.innerHTML = `
    <option value="">${i18n.t('attendance.selectStudent')}</option>
    ${studentsCache.map(student =>
        `<option value="${student.id}">${student.name} (${student.rollNumber})</option>`
    ).join('')}
  `;

    modal.classList.add('active');
}

function closePerformanceModal() {
    document.getElementById('performanceModal').classList.remove('active');
}

async function savePerformance(event) {
    event.preventDefault();

    const formData = new FormData(event.target);
    const performanceData = {
        studentId: parseInt(formData.get('studentId')),
        subject: formData.get('subject'),
        marks: parseFloat(formData.get('marks')),
        maxMarks: parseFloat(formData.get('maxMarks')) || 100,
        examType: formData.get('examType'),
        examDate: formData.get('examDate')
    };

    try {
        const result = await apiCall('/performance', {
            method: 'POST',
            body: JSON.stringify(performanceData)
        });

        showNotification(i18n.t('performance.performanceAdded'), 'success');

        // Show AI remarks
        if (result.aiRemarks) {
            const alertType = result.aiRemarks.category === 'Excellent' ? 'success' :
                result.aiRemarks.category === 'Good' ? 'info' :
                    result.aiRemarks.category === 'Average' ? 'warning' : 'danger';

            showNotification(`AI: ${result.aiRemarks.remark}`, alertType);
        }

        closePerformanceModal();
        await loadPerformance();
    } catch (error) {
        // Error already shown by apiCall
    }
}

async function viewPerformanceReport() {
    const studentId = document.getElementById('performanceStudentSelect').value;
    if (!studentId) {
        showNotification('Please select a student', 'warning');
        return;
    }

    try {
        const result = await apiCall(`/performance/student/${studentId}/report`);

        const modal = document.getElementById('performanceReportModal');
        const content = document.getElementById('performanceReportContent');

        const student = result.student;
        const summary = result.summary;
        const subjectWise = result.subjectWisePerformance || [];
        const overallRemarks = result.overallRemarks;

        content.innerHTML = `
      <h3>${student.name} (${student.rollNumber})</h3>
      <p style="color: var(--text-secondary);">${student.class || ''}</p>

      <div class="stats-grid" style="margin: 1.5rem 0;">
        <div class="stat-card">
          <div class="stat-label">${i18n.t('performance.averageMarks')}</div>
          <div class="stat-value">${summary.averageMarks}%</div>
        </div>
        <div class="stat-card success">
          <div class="stat-label">Highest</div>
          <div class="stat-value">${summary.highestMarks}</div>
        </div>
        <div class="stat-card warning">
          <div class="stat-label">Lowest</div>
          <div class="stat-value">${summary.lowestMarks}</div>
        </div>
      </div>

      ${overallRemarks ? `
        <div class="alert alert-${getCategoryBadge(overallRemarks.category).replace('badge-', '')}">
          <div class="ai-badge" style="margin-bottom: 0.5rem;">
            🤖 ${i18n.t('ai.generated')}
          </div>
          <strong>${overallRemarks.category}</strong><br>
          ${overallRemarks.remark}
          ${overallRemarks.suggestions && overallRemarks.suggestions.length > 0 ? `
            <br><br><strong>${i18n.t('performance.suggestions')}:</strong>
            <ul style="margin: 0.5rem 0 0 1.5rem;">
              ${overallRemarks.suggestions.map(s => `<li>${s}</li>`).join('')}
            </ul>
          ` : ''}
        </div>
      ` : ''}

      <h4 style="margin-top: 1.5rem;">Subject-wise Performance</h4>
      ${subjectWise.length > 0 ? `
        <div class="table-container">
          <table class="table">
            <thead>
              <tr>
                <th>${i18n.t('performance.subject')}</th>
                <th>Records</th>
                <th>Average</th>
                <th>Highest</th>
                <th>Lowest</th>
              </tr>
            </thead>
            <tbody>
              ${subjectWise.map(subject => `
                <tr>
                  <td><strong>${subject.subject}</strong></td>
                  <td>${subject.recordCount}</td>
                  <td><span class="badge ${parseFloat(subject.averageMarks) >= 75 ? 'badge-success' : 'badge-warning'}">${subject.averageMarks}%</span></td>
                  <td>${subject.highestMarks}</td>
                  <td>${subject.lowestMarks}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      ` : '<p>No performance records found</p>'}
    `;

        modal.classList.add('active');
    } catch (error) {
        // Error already shown by apiCall
    }
}

function closePerformanceReportModal() {
    document.getElementById('performanceReportModal').classList.remove('active');
}

function initPerformanceModule() {
    const form = document.getElementById('performanceForm');
    if (form) {
        form.addEventListener('submit', savePerformance);
    }

    const closeBtn = document.getElementById('closePerformanceModal');
    if (closeBtn) {
        closeBtn.addEventListener('click', closePerformanceModal);
    }

    const addBtn = document.getElementById('addPerformanceBtn');
    if (addBtn) {
        addBtn.addEventListener('click', showAddPerformanceModal);
    }

    const viewBtn = document.getElementById('viewReportBtn');
    if (viewBtn) {
        viewBtn.addEventListener('click', viewPerformanceReport);
    }

    const closeReportBtn = document.getElementById('closePerformanceReportModal');
    if (closeReportBtn) {
        closeReportBtn.addEventListener('click', closePerformanceReportModal);
    }
}

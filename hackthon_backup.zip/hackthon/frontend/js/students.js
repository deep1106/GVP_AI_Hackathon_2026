// Students Module

let studentsCache = [];

async function loadStudents() {
    try {
        const data = await apiCall('/students');
        studentsCache = data.data || [];
        renderStudentsList();
    } catch (error) {
        console.error('Error loading students:', error);
    }
}

function renderStudentsList() {
    const container = document.getElementById('studentsList');

    if (studentsCache.length === 0) {
        container.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">👥</div>
        <div class="empty-state-text">${i18n.t('common.noData')}</div>
        <button class="btn btn-primary" onclick="showAddStudentModal()">
          ${i18n.t('students.addStudent')}
        </button>
      </div>
    `;
        return;
    }

    container.innerHTML = `
    <div class="table-container">
      <table class="table">
        <thead>
          <tr>
            <th>${i18n.t('students.name')}</th>
            <th>${i18n.t('students.rollNumber')}</th>
            <th>${i18n.t('students.class')}</th>
            <th>${i18n.t('students.email')}</th>
            <th>${i18n.t('common.actions') || 'Actions'}</th>
          </tr>
        </thead>
        <tbody>
          ${studentsCache.map(student => `
            <tr>
              <td><strong>${student.name}</strong></td>
              <td>${student.rollNumber}</td>
              <td>${student.class || '-'}</td>
              <td>${student.email || '-'}</td>
              <td>
                <button class="btn btn-sm btn-danger" onclick="deleteStudent(${student.id})">
                  🗑️ ${i18n.t('common.delete')}
                </button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function showAddStudentModal() {
    const modal = document.getElementById('studentModal');
    document.getElementById('studentForm').reset();
    document.getElementById('studentModalTitle').textContent = i18n.t('students.addStudent');
    modal.classList.add('active');
}

function closeStudentModal() {
    document.getElementById('studentModal').classList.remove('active');
}

async function saveStudent(event) {
    event.preventDefault();

    const formData = new FormData(event.target);
    const studentData = {
        name: formData.get('name'),
        rollNumber: formData.get('rollNumber'),
        class: formData.get('class'),
        email: formData.get('email')
    };

    try {
        const result = await apiCall('/students', {
            method: 'POST',
            body: JSON.stringify(studentData)
        });

        showNotification(i18n.t('students.studentAdded'), 'success');

        // Show AI insights if available
        if (result.aiInsights && result.aiInsights.length > 0) {
            showNotification(`AI: ${result.aiInsights[0]}`, 'info');
        }

        closeStudentModal();
        await loadStudents();
    } catch (error) {
        // Error already shown by apiCall
    }
}

async function deleteStudent(id) {
    if (!confirm(i18n.t('students.confirmDelete'))) {
        return;
    }

    try {
        await apiCall(`/students/${id}`, { method: 'DELETE' });
        showNotification(i18n.t('students.studentDeleted'), 'success');
        await loadStudents();
    } catch (error) {
        // Error already shown by apiCall
    }
}

async function generateSampleStudents() {
    try {
        const result = await apiCall('/students/generate-samples', {
            method: 'POST',
            body: JSON.stringify({ count: 5 })
        });

        showNotification(result.message, 'success');
        await loadStudents();
    } catch (error) {
        // Error already shown by apiCall
    }
}

function initStudentsModule() {
    // Setup form submission
    const form = document.getElementById('studentForm');
    if (form) {
        form.addEventListener('submit', saveStudent);
    }

    // Setup modal close
    const closeBtn = document.getElementById('closeStudentModal');
    if (closeBtn) {
        closeBtn.addEventListener('click', closeStudentModal);
    }

    // Setup add button
    const addBtn = document.getElementById('addStudentBtn');
    if (addBtn) {
        addBtn.addEventListener('click', showAddStudentModal);
    }

    // Setup generate samples button
    const generateBtn = document.getElementById('generateSamplesBtn');
    if (generateBtn) {
        generateBtn.addEventListener('click', generateSampleStudents);
    }
}

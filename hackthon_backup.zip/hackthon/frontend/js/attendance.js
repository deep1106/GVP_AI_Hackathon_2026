// Attendance Module

let attendanceCache = [];

async function loadAttendance() {
    try {
        const [studentsData, statsData] = await Promise.all([
            apiCall('/students'),
            apiCall('/attendance/stats')
        ]);

        studentsCache = studentsData.data || [];
        renderAttendanceStats(statsData.data || []);
        populateStudentSelect();
    } catch (error) {
        console.error('Error loading attendance:', error);
    }
}

function renderAttendanceStats(stats) {
    const container = document.getElementById('attendanceStats');

    if (stats.length === 0) {
        container.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">📊</div>
        <div class="empty-state-text">${i18n.t('common.noData')}</div>
      </div>
    `;
        return;
    }

    container.innerHTML = `
    <div class="table-container">
      <table class="table">
        <thead>
          <tr>
            <th>${i18n.t('students.name')}</th>
            <th>${i18n.t('students.rollNumber')}</th>
            <th>${i18n.t('attendance.percentage')}</th>
            <th>${i18n.t('attendance.status')}</th>
          </tr>
        </thead>
        <tbody>
          ${stats.map(student => {
        const percentage = parseFloat(student.attendancePercentage);
        let badgeClass = 'badge-success';
        if (percentage < 75) badgeClass = 'badge-danger';
        else if (percentage < 80) badgeClass = 'badge-warning';

        return `
              <tr>
                <td><strong>${student.name}</strong></td>
                <td>${student.rollNumber}</td>
                <td><span class="badge ${badgeClass}">${student.attendancePercentage}%</span></td>
                <td>
                  ${percentage < 75 ? '⚠️ ' + i18n.t('attendance.criticalThreshold') :
                percentage < 80 ? '⚡ ' + i18n.t('attendance.warningThreshold') :
                    '✅ Good'}
                </td>
              </tr>
            `;
    }).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function populateStudentSelect() {
    const select = document.getElementById('attendanceStudentSelect');
    if (!select) return;

    select.innerHTML = `
    <option value="">${i18n.t('attendance.selectStudent')}</option>
    ${studentsCache.map(student =>
        `<option value="${student.id}">${student.name} (${student.rollNumber})</option>`
    ).join('')}
  `;
}

function showMarkAttendanceModal() {
    const modal = document.getElementById('attendanceModal');
    document.getElementById('attendanceForm').reset();

    // Set today's date
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('attendanceDate').value = today;

    // Populate student select in modal
    const modalSelect = document.getElementById('attendanceModalStudentSelect');
    modalSelect.innerHTML = `
    <option value="">${i18n.t('attendance.selectStudent')}</option>
    ${studentsCache.map(student =>
        `<option value="${student.id}">${student.name} (${student.rollNumber})</option>`
    ).join('')}
  `;

    modal.classList.add('active');
}

function closeAttendanceModal() {
    document.getElementById('attendanceModal').classList.remove('active');
}

async function saveAttendance(event) {
    event.preventDefault();

    const formData = new FormData(event.target);
    const attendanceData = {
        studentId: parseInt(formData.get('studentId')),
        date: formData.get('date'),
        status: formData.get('status'),
        remarks: formData.get('remarks') || ''
    };

    try {
        const result = await apiCall('/attendance', {
            method: 'POST',
            body: JSON.stringify(attendanceData)
        });

        showNotification(i18n.t('attendance.attendanceMarked'), 'success');

        // Show AI warning if available
        if (result.aiInsights) {
            const severity = result.aiInsights.severity;
            const alertType = severity === 'critical' ? 'danger' :
                severity === 'warning' ? 'warning' : 'success';
            showNotification(result.aiInsights.message, alertType);
        }

        closeAttendanceModal();
        await loadAttendance();
    } catch (error) {
        // Error already shown by apiCall
    }
}

async function viewStudentAttendance() {
    const studentId = document.getElementById('attendanceStudentSelect').value;
    if (!studentId) {
        showNotification('Please select a student', 'warning');
        return;
    }

    try {
        const result = await apiCall(`/attendance/student/${studentId}`);

        const modal = document.getElementById('attendanceDetailsModal');
        const content = document.getElementById('attendanceDetailsContent');

        const student = result.student;
        const attendance = result.attendance;
        const aiInsights = result.aiInsights;

        content.innerHTML = `
      <h3>${student.name} (${student.rollNumber})</h3>
      <div class="stats-grid" style="margin: 1rem 0;">
        <div class="stat-card ${aiInsights.severity === 'critical' ? 'danger' : aiInsights.severity === 'warning' ? 'warning' : 'success'}">
          <div class="stat-label">${i18n.t('attendance.percentage')}</div>
          <div class="stat-value">${attendance.percentage}%</div>
        </div>
      </div>
      
      ${aiInsights.message ? `
        <div class="alert alert-${aiInsights.severity === 'critical' ? 'danger' : aiInsights.severity === 'warning' ? 'warning' : 'info'}">
          <strong>AI Insights:</strong><br>
          ${aiInsights.message}
          ${aiInsights.suggestions && aiInsights.suggestions.length > 0 ? `
            <br><br><strong>Suggestions:</strong>
            <ul style="margin: 0.5rem 0 0 1.5rem;">
              ${aiInsights.suggestions.map(s => `<li>${s}</li>`).join('')}
            </ul>
          ` : ''}
        </div>
      ` : ''}

      <h4 style="margin-top: 1.5rem;">Attendance Records</h4>
      ${attendance.records.length > 0 ? `
        <div class="table-container">
          <table class="table">
            <thead>
              <tr>
                <th>${i18n.t('attendance.date')}</th>
                <th>${i18n.t('attendance.status')}</th>
                <th>${i18n.t('attendance.remarks')}</th>
              </tr>
            </thead>
            <tbody>
              ${attendance.records.map(record => `
                <tr>
                  <td>${new Date(record.date).toLocaleDateString()}</td>
                  <td><span class="badge badge-${record.status === 'present' ? 'success' : 'danger'}">${record.status}</span></td>
                  <td>${record.remarks || '-'}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      ` : '<p>No attendance records found</p>'}
    `;

        modal.classList.add('active');
    } catch (error) {
        // Error already shown by apiCall
    }
}

function closeAttendanceDetailsModal() {
    document.getElementById('attendanceDetailsModal').classList.remove('active');
}

function initAttendanceModule() {
    const form = document.getElementById('attendanceForm');
    if (form) {
        form.addEventListener('submit', saveAttendance);
    }

    const closeBtn = document.getElementById('closeAttendanceModal');
    if (closeBtn) {
        closeBtn.addEventListener('click', closeAttendanceModal);
    }

    const markBtn = document.getElementById('markAttendanceBtn');
    if (markBtn) {
        markBtn.addEventListener('click', showMarkAttendanceModal);
    }

    const viewBtn = document.getElementById('viewAttendanceBtn');
    if (viewBtn) {
        viewBtn.addEventListener('click', viewStudentAttendance);
    }

    const closeDetailsBtn = document.getElementById('closeAttendanceDetailsModal');
    if (closeDetailsBtn) {
        closeDetailsBtn.addEventListener('click', closeAttendanceDetailsModal);
    }
}

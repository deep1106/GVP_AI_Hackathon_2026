const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const path = require('path');

// Import routes
const studentsRouter = require('./routes/students');
const attendanceRouter = require('./routes/attendance');
const performanceRouter = require('./routes/performance');

// Import data store
const dataStore = require('./data/store');

// Create Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Security middleware
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
            fontSrc: ["'self'", "https://fonts.gstatic.com"],
            scriptSrc: ["'self'"],
            imgSrc: ["'self'", "data:", "https:"],
        },
    },
}));

// CORS middleware
app.use(cors());

// Body parser middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from frontend directory
app.use(express.static(path.join(__dirname, '../frontend')));

// API Routes
app.use('/api/students', studentsRouter);
app.use('/api/attendance', attendanceRouter);
app.use('/api/performance', performanceRouter);

// Health check endpoint
app.get('/api/health', (req, res) => {
    const stats = dataStore.getStats();
    res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        stats
    });
});

// Root API endpoint
app.get('/api', (req, res) => {
    res.json({
        message: 'AI-Assisted Smart Attendance & Performance Tracker API',
        version: '1.0.0',
        endpoints: {
            students: '/api/students',
            attendance: '/api/attendance',
            performance: '/api/performance',
            health: '/api/health'
        },
        features: [
            'Student Management',
            'Attendance Tracking with AI Warnings',
            'Performance Evaluation with AI Remarks',
            'Multi-language Support',
            'Light/Dark Theme',
            'Responsive Design'
        ]
    });
});

// Serve index.html for all other routes (SPA support)
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Error:', err.stack);
    res.status(500).json({
        success: false,
        message: 'Internal server error',
        error: process.env.NODE_ENV === 'development' ? err.message : 'An error occurred'
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`
╔═══════════════════════════════════════════════════════════════╗
║  AI-Assisted Smart Attendance & Performance Tracker          ║
╠═══════════════════════════════════════════════════════════════╣
║  Server running on: http://localhost:${PORT}                    ║
║  API Documentation: http://localhost:${PORT}/api                ║
║  Health Check: http://localhost:${PORT}/api/health              ║
╚═══════════════════════════════════════════════════════════════╝
  `);
});

module.exports = app;

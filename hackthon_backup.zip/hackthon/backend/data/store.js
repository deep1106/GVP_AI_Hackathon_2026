// In-memory data store
class DataStore {
  constructor() {
    this.students = [];
    this.attendance = [];
    this.performance = [];
    this.nextStudentId = 1;
  }

  // Student operations
  addStudent(student) {
    const newStudent = {
      id: this.nextStudentId++,
      ...student,
      createdAt: new Date().toISOString()
    };
    this.students.push(newStudent);
    return newStudent;
  }

  getStudents() {
    return this.students;
  }

  getStudentById(id) {
    return this.students.find(s => s.id === parseInt(id));
  }

  getStudentByRollNumber(rollNumber) {
    return this.students.find(s => s.rollNumber === rollNumber);
  }

  updateStudent(id, updates) {
    const index = this.students.findIndex(s => s.id === parseInt(id));
    if (index !== -1) {
      this.students[index] = { ...this.students[index], ...updates };
      return this.students[index];
    }
    return null;
  }

  deleteStudent(id) {
    const index = this.students.findIndex(s => s.id === parseInt(id));
    if (index !== -1) {
      const deleted = this.students.splice(index, 1);
      // Also delete related attendance and performance records
      this.attendance = this.attendance.filter(a => a.studentId !== parseInt(id));
      this.performance = this.performance.filter(p => p.studentId !== parseInt(id));
      return deleted[0];
    }
    return null;
  }

  // Attendance operations
  markAttendance(attendanceRecord) {
    const record = {
      id: this.attendance.length + 1,
      ...attendanceRecord,
      createdAt: new Date().toISOString()
    };
    this.attendance.push(record);
    return record;
  }

  getAttendanceByStudent(studentId) {
    return this.attendance.filter(a => a.studentId === parseInt(studentId));
  }

  getAllAttendance() {
    return this.attendance;
  }

  calculateAttendancePercentage(studentId) {
    const records = this.getAttendanceByStudent(studentId);
    if (records.length === 0) return 0;
    
    const presentCount = records.filter(r => r.status === 'present').length;
    return (presentCount / records.length) * 100;
  }

  // Performance operations
  addPerformance(performanceRecord) {
    const record = {
      id: this.performance.length + 1,
      ...performanceRecord,
      createdAt: new Date().toISOString()
    };
    this.performance.push(record);
    return record;
  }

  getPerformanceByStudent(studentId) {
    return this.performance.filter(p => p.studentId === parseInt(studentId));
  }

  getAllPerformance() {
    return this.performance;
  }

  updatePerformance(id, updates) {
    const index = this.performance.findIndex(p => p.id === parseInt(id));
    if (index !== -1) {
      this.performance[index] = { ...this.performance[index], ...updates };
      return this.performance[index];
    }
    return null;
  }

  // Utility methods
  reset() {
    this.students = [];
    this.attendance = [];
    this.performance = [];
    this.nextStudentId = 1;
  }

  getStats() {
    return {
      totalStudents: this.students.length,
      totalAttendanceRecords: this.attendance.length,
      totalPerformanceRecords: this.performance.length
    };
  }
}

// Export singleton instance
module.exports = new DataStore();

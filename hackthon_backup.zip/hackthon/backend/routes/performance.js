const express = require('express');
const router = express.Router();
const dataStore = require('../data/store');
const { validatePerformance, sanitizeObject } = require('../services/validation');
const { generatePerformanceRemarks, analyzeClassPerformance, validateWithAI } = require('../services/aiService');

/**
 * GET /api/performance
 * Get all performance records
 */
router.get('/', (req, res) => {
    try {
        const performance = dataStore.getAllPerformance();
        res.json({
            success: true,
            count: performance.length,
            data: performance
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching performance records',
            error: error.message
        });
    }
});

/**
 * GET /api/performance/student/:studentId
 * Get performance records for a specific student
 */
router.get('/student/:studentId', (req, res) => {
    try {
        const student = dataStore.getStudentById(req.params.studentId);

        if (!student) {
            return res.status(404).json({
                success: false,
                message: 'Student not found'
            });
        }

        const performance = dataStore.getPerformanceByStudent(req.params.studentId);

        // Calculate average marks
        let averageMarks = 0;
        if (performance.length > 0) {
            const totalMarks = performance.reduce((sum, p) => sum + parseFloat(p.marks), 0);
            averageMarks = totalMarks / performance.length;
        }

        res.json({
            success: true,
            student: {
                id: student.id,
                name: student.name,
                rollNumber: student.rollNumber
            },
            performance: {
                records: performance,
                totalRecords: performance.length,
                averageMarks: averageMarks.toFixed(2)
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching student performance',
            error: error.message
        });
    }
});

/**
 * POST /api/performance
 * Add performance record for a student
 */
router.post('/', (req, res) => {
    try {
        // Sanitize input
        const sanitizedData = sanitizeObject(req.body);

        // Validate performance data
        const validation = validatePerformance(sanitizedData);

        if (!validation.isValid) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: validation.errors
            });
        }

        // Verify student exists
        const student = dataStore.getStudentById(sanitizedData.studentId);
        if (!student) {
            return res.status(404).json({
                success: false,
                message: 'Student not found'
            });
        }

        // Get AI insights on the marks
        const aiInsights = validateWithAI(sanitizedData, 'performance');

        // Generate AI-powered performance remarks
        const maxMarks = sanitizedData.maxMarks || 100;
        const aiRemarks = generatePerformanceRemarks(
            parseFloat(sanitizedData.marks),
            parseFloat(maxMarks),
            sanitizedData.subject
        );

        // Create performance record
        const performanceRecord = dataStore.addPerformance({
            studentId: parseInt(sanitizedData.studentId),
            subject: sanitizedData.subject,
            marks: parseFloat(sanitizedData.marks),
            maxMarks: parseFloat(maxMarks),
            examType: sanitizedData.examType || 'Regular',
            examDate: sanitizedData.examDate || new Date().toISOString(),
            remarks: aiRemarks.remark,
            category: aiRemarks.category,
            aiGenerated: true
        });

        res.status(201).json({
            success: true,
            message: 'Performance record added successfully',
            data: performanceRecord,
            aiRemarks: aiRemarks,
            aiInsights: aiInsights.aiInsights.length > 0 ? aiInsights.aiInsights : undefined
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error adding performance record',
            error: error.message
        });
    }
});

/**
 * PUT /api/performance/:id
 * Update performance record
 */
router.put('/:id', (req, res) => {
    try {
        // Sanitize input
        const sanitizedData = sanitizeObject(req.body);

        // If marks are being updated, regenerate AI remarks
        let updates = { ...sanitizedData };

        if (sanitizedData.marks !== undefined) {
            const validation = validatePerformance({
                ...sanitizedData,
                studentId: sanitizedData.studentId || 1, // Dummy ID for validation
                subject: sanitizedData.subject || 'Subject'
            });

            if (!validation.isValid) {
                return res.status(400).json({
                    success: false,
                    message: 'Validation failed',
                    errors: validation.errors
                });
            }

            const maxMarks = sanitizedData.maxMarks || 100;
            const aiRemarks = generatePerformanceRemarks(
                parseFloat(sanitizedData.marks),
                parseFloat(maxMarks),
                sanitizedData.subject || 'Subject'
            );

            updates.remarks = aiRemarks.remark;
            updates.category = aiRemarks.category;
            updates.marks = parseFloat(sanitizedData.marks);
        }

        const updatedRecord = dataStore.updatePerformance(req.params.id, updates);

        if (!updatedRecord) {
            return res.status(404).json({
                success: false,
                message: 'Performance record not found'
            });
        }

        res.json({
            success: true,
            message: 'Performance record updated successfully',
            data: updatedRecord
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error updating performance record',
            error: error.message
        });
    }
});

/**
 * GET /api/performance/analyze/:subject
 * Analyze class performance for a specific subject
 */
router.get('/analyze/:subject', (req, res) => {
    try {
        const subject = req.params.subject;
        const allPerformance = dataStore.getAllPerformance();

        // Filter by subject
        const subjectPerformance = allPerformance.filter(p =>
            p.subject.toLowerCase() === subject.toLowerCase()
        );

        if (subjectPerformance.length === 0) {
            return res.status(404).json({
                success: false,
                message: `No performance records found for subject: ${subject}`
            });
        }

        // Get AI analysis
        const analysis = analyzeClassPerformance(subjectPerformance);

        res.json({
            success: true,
            subject: subject,
            totalRecords: subjectPerformance.length,
            analysis: analysis
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error analyzing performance',
            error: error.message
        });
    }
});

/**
 * GET /api/performance/analyze
 * Analyze overall class performance across all subjects
 */
router.get('/analyze', (req, res) => {
    try {
        const allPerformance = dataStore.getAllPerformance();

        if (allPerformance.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'No performance records found'
            });
        }

        // Get overall analysis
        const overallAnalysis = analyzeClassPerformance(allPerformance);

        // Group by subject
        const subjects = [...new Set(allPerformance.map(p => p.subject))];
        const subjectAnalysis = subjects.map(subject => {
            const subjectRecords = allPerformance.filter(p => p.subject === subject);
            return {
                subject,
                analysis: analyzeClassPerformance(subjectRecords)
            };
        });

        res.json({
            success: true,
            totalRecords: allPerformance.length,
            overallAnalysis,
            subjectAnalysis
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error analyzing performance',
            error: error.message
        });
    }
});

/**
 * GET /api/performance/student/:studentId/report
 * Generate comprehensive performance report for a student
 */
router.get('/student/:studentId/report', (req, res) => {
    try {
        const student = dataStore.getStudentById(req.params.studentId);

        if (!student) {
            return res.status(404).json({
                success: false,
                message: 'Student not found'
            });
        }

        const performance = dataStore.getPerformanceByStudent(req.params.studentId);

        if (performance.length === 0) {
            return res.json({
                success: true,
                student: {
                    id: student.id,
                    name: student.name,
                    rollNumber: student.rollNumber
                },
                message: 'No performance records found for this student'
            });
        }

        // Calculate statistics
        const marks = performance.map(p => parseFloat(p.marks));
        const averageMarks = marks.reduce((a, b) => a + b, 0) / marks.length;
        const highestMarks = Math.max(...marks);
        const lowestMarks = Math.min(...marks);

        // Group by subject
        const subjects = [...new Set(performance.map(p => p.subject))];
        const subjectWisePerformance = subjects.map(subject => {
            const subjectRecords = performance.filter(p => p.subject === subject);
            const subjectMarks = subjectRecords.map(p => parseFloat(p.marks));
            const subjectAverage = subjectMarks.reduce((a, b) => a + b, 0) / subjectMarks.length;

            return {
                subject,
                recordCount: subjectRecords.length,
                averageMarks: subjectAverage.toFixed(2),
                highestMarks: Math.max(...subjectMarks),
                lowestMarks: Math.min(...subjectMarks),
                latestRecord: subjectRecords[subjectRecords.length - 1]
            };
        });

        // Generate overall AI remarks
        const overallRemarks = generatePerformanceRemarks(averageMarks, 100, 'Overall Performance');

        res.json({
            success: true,
            student: {
                id: student.id,
                name: student.name,
                rollNumber: student.rollNumber,
                class: student.class
            },
            summary: {
                totalRecords: performance.length,
                averageMarks: averageMarks.toFixed(2),
                highestMarks,
                lowestMarks,
                subjectsCount: subjects.length
            },
            subjectWisePerformance,
            overallRemarks,
            aiGenerated: true
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error generating performance report',
            error: error.message
        });
    }
});

module.exports = router;

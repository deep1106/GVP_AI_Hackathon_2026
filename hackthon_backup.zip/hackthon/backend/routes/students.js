const express = require('express');
const router = express.Router();
const dataStore = require('../data/store');
const { validateStudent, sanitizeObject } = require('../services/validation');
const { validateWithAI, generateSampleStudents } = require('../services/aiService');

/**
 * GET /api/students
 * Get all students
 */
router.get('/', (req, res) => {
    try {
        const students = dataStore.getStudents();
        res.json({
            success: true,
            count: students.length,
            data: students
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching students',
            error: error.message
        });
    }
});

/**
 * GET /api/students/:id
 * Get student by ID
 */
router.get('/:id', (req, res) => {
    try {
        const student = dataStore.getStudentById(req.params.id);

        if (!student) {
            return res.status(404).json({
                success: false,
                message: 'Student not found'
            });
        }

        res.json({
            success: true,
            data: student
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching student',
            error: error.message
        });
    }
});

/**
 * POST /api/students
 * Create new student
 */
router.post('/', (req, res) => {
    try {
        // Sanitize input
        const sanitizedData = sanitizeObject(req.body);

        // Validate student data
        const validation = validateStudent(sanitizedData);

        if (!validation.isValid) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: validation.errors
            });
        }

        // Check for duplicate roll number
        const existingStudent = dataStore.getStudentByRollNumber(sanitizedData.rollNumber);
        if (existingStudent) {
            return res.status(409).json({
                success: false,
                message: 'A student with this roll number already exists',
                existingStudent: {
                    id: existingStudent.id,
                    name: existingStudent.name,
                    rollNumber: existingStudent.rollNumber
                }
            });
        }

        // Get AI insights
        const aiInsights = validateWithAI(sanitizedData, 'student');

        // Create student
        const newStudent = dataStore.addStudent(sanitizedData);

        res.status(201).json({
            success: true,
            message: 'Student created successfully',
            data: newStudent,
            aiInsights: aiInsights.aiInsights.length > 0 ? aiInsights.aiInsights : undefined,
            suggestions: aiInsights.suggestions.length > 0 ? aiInsights.suggestions : undefined
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error creating student',
            error: error.message
        });
    }
});

/**
 * PUT /api/students/:id
 * Update student
 */
router.put('/:id', (req, res) => {
    try {
        // Sanitize input
        const sanitizedData = sanitizeObject(req.body);

        // Validate student data
        const validation = validateStudent(sanitizedData);

        if (!validation.isValid) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: validation.errors
            });
        }

        // Check if roll number is being changed and if it conflicts
        if (sanitizedData.rollNumber) {
            const existingStudent = dataStore.getStudentByRollNumber(sanitizedData.rollNumber);
            if (existingStudent && existingStudent.id !== parseInt(req.params.id)) {
                return res.status(409).json({
                    success: false,
                    message: 'A student with this roll number already exists'
                });
            }
        }

        // Update student
        const updatedStudent = dataStore.updateStudent(req.params.id, sanitizedData);

        if (!updatedStudent) {
            return res.status(404).json({
                success: false,
                message: 'Student not found'
            });
        }

        res.json({
            success: true,
            message: 'Student updated successfully',
            data: updatedStudent
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error updating student',
            error: error.message
        });
    }
});

/**
 * DELETE /api/students/:id
 * Delete student
 */
router.delete('/:id', (req, res) => {
    try {
        const deletedStudent = dataStore.deleteStudent(req.params.id);

        if (!deletedStudent) {
            return res.status(404).json({
                success: false,
                message: 'Student not found'
            });
        }

        res.json({
            success: true,
            message: 'Student deleted successfully',
            data: deletedStudent
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error deleting student',
            error: error.message
        });
    }
});

/**
 * POST /api/students/generate-samples
 * Generate sample students for testing
 */
router.post('/generate-samples', (req, res) => {
    try {
        const count = parseInt(req.body.count) || 5;

        if (count < 1 || count > 50) {
            return res.status(400).json({
                success: false,
                message: 'Count must be between 1 and 50'
            });
        }

        const sampleStudents = generateSampleStudents(count);
        const createdStudents = [];

        for (const student of sampleStudents) {
            // Check for duplicate roll numbers
            if (!dataStore.getStudentByRollNumber(student.rollNumber)) {
                createdStudents.push(dataStore.addStudent(student));
            }
        }

        res.status(201).json({
            success: true,
            message: `Generated ${createdStudents.length} sample students`,
            data: createdStudents,
            aiGenerated: true
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error generating sample students',
            error: error.message
        });
    }
});

module.exports = router;

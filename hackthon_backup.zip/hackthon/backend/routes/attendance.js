const express = require('express');
const router = express.Router();
const dataStore = require('../data/store');
const { validateAttendance, sanitizeObject } = require('../services/validation');
const { generateAttendanceWarning } = require('../services/aiService');

/**
 * GET /api/attendance
 * Get all attendance records
 */
router.get('/', (req, res) => {
    try {
        const attendance = dataStore.getAllAttendance();
        res.json({
            success: true,
            count: attendance.length,
            data: attendance
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching attendance records',
            error: error.message
        });
    }
});

/**
 * GET /api/attendance/student/:studentId
 * Get attendance records for a specific student
 */
router.get('/student/:studentId', (req, res) => {
    try {
        const student = dataStore.getStudentById(req.params.studentId);

        if (!student) {
            return res.status(404).json({
                success: false,
                message: 'Student not found'
            });
        }

        const attendance = dataStore.getAttendanceByStudent(req.params.studentId);
        const percentage = dataStore.calculateAttendancePercentage(req.params.studentId);

        // Generate AI-powered attendance warning/insights
        const aiWarning = generateAttendanceWarning(percentage, student.name);

        res.json({
            success: true,
            student: {
                id: student.id,
                name: student.name,
                rollNumber: student.rollNumber
            },
            attendance: {
                records: attendance,
                totalRecords: attendance.length,
                presentCount: attendance.filter(a => a.status === 'present').length,
                absentCount: attendance.filter(a => a.status === 'absent').length,
                lateCount: attendance.filter(a => a.status === 'late').length,
                excusedCount: attendance.filter(a => a.status === 'excused').length,
                percentage: percentage.toFixed(2)
            },
            aiInsights: aiWarning
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching student attendance',
            error: error.message
        });
    }
});

/**
 * POST /api/attendance
 * Mark attendance for a student
 */
router.post('/', (req, res) => {
    try {
        // Sanitize input
        const sanitizedData = sanitizeObject(req.body);

        // Validate attendance data
        const validation = validateAttendance(sanitizedData);

        if (!validation.isValid) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: validation.errors
            });
        }

        // Verify student exists
        const student = dataStore.getStudentById(sanitizedData.studentId);
        if (!student) {
            return res.status(404).json({
                success: false,
                message: 'Student not found'
            });
        }

        // Check for duplicate attendance on same date
        const existingAttendance = dataStore.getAttendanceByStudent(sanitizedData.studentId);
        const dateStr = new Date(sanitizedData.date).toISOString().split('T')[0];
        const duplicateRecord = existingAttendance.find(a => {
            const recordDate = new Date(a.date).toISOString().split('T')[0];
            return recordDate === dateStr;
        });

        if (duplicateRecord) {
            return res.status(409).json({
                success: false,
                message: 'Attendance already marked for this date',
                existingRecord: duplicateRecord
            });
        }

        // Mark attendance
        const attendanceRecord = dataStore.markAttendance({
            studentId: parseInt(sanitizedData.studentId),
            date: sanitizedData.date,
            status: sanitizedData.status.toLowerCase(),
            remarks: sanitizedData.remarks || ''
        });

        // Calculate updated percentage
        const percentage = dataStore.calculateAttendancePercentage(sanitizedData.studentId);

        // Generate AI warning if needed
        const aiWarning = generateAttendanceWarning(percentage, student.name);

        res.status(201).json({
            success: true,
            message: 'Attendance marked successfully',
            data: attendanceRecord,
            attendancePercentage: percentage.toFixed(2),
            aiInsights: aiWarning
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error marking attendance',
            error: error.message
        });
    }
});

/**
 * POST /api/attendance/bulk
 * Mark attendance for multiple students at once
 */
router.post('/bulk', (req, res) => {
    try {
        const { date, attendanceList } = req.body;

        if (!date || !attendanceList || !Array.isArray(attendanceList)) {
            return res.status(400).json({
                success: false,
                message: 'Date and attendanceList array are required'
            });
        }

        const results = {
            success: [],
            failed: []
        };

        for (const item of attendanceList) {
            try {
                const sanitizedData = sanitizeObject({
                    studentId: item.studentId,
                    date: date,
                    status: item.status,
                    remarks: item.remarks || ''
                });

                const validation = validateAttendance(sanitizedData);

                if (!validation.isValid) {
                    results.failed.push({
                        studentId: item.studentId,
                        errors: validation.errors
                    });
                    continue;
                }

                const student = dataStore.getStudentById(sanitizedData.studentId);
                if (!student) {
                    results.failed.push({
                        studentId: item.studentId,
                        errors: ['Student not found']
                    });
                    continue;
                }

                // Check for duplicate
                const existingAttendance = dataStore.getAttendanceByStudent(sanitizedData.studentId);
                const dateStr = new Date(date).toISOString().split('T')[0];
                const duplicateRecord = existingAttendance.find(a => {
                    const recordDate = new Date(a.date).toISOString().split('T')[0];
                    return recordDate === dateStr;
                });

                if (duplicateRecord) {
                    results.failed.push({
                        studentId: item.studentId,
                        errors: ['Attendance already marked for this date']
                    });
                    continue;
                }

                const record = dataStore.markAttendance({
                    studentId: parseInt(sanitizedData.studentId),
                    date: sanitizedData.date,
                    status: sanitizedData.status.toLowerCase(),
                    remarks: sanitizedData.remarks
                });

                results.success.push(record);
            } catch (error) {
                results.failed.push({
                    studentId: item.studentId,
                    errors: [error.message]
                });
            }
        }

        res.status(201).json({
            success: true,
            message: `Marked attendance for ${results.success.length} students`,
            successCount: results.success.length,
            failedCount: results.failed.length,
            data: results
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error marking bulk attendance',
            error: error.message
        });
    }
});

/**
 * GET /api/attendance/stats
 * Get overall attendance statistics
 */
router.get('/stats', (req, res) => {
    try {
        const students = dataStore.getStudents();
        const stats = students.map(student => {
            const percentage = dataStore.calculateAttendancePercentage(student.id);
            const aiWarning = generateAttendanceWarning(percentage, student.name);

            return {
                studentId: student.id,
                name: student.name,
                rollNumber: student.rollNumber,
                attendancePercentage: percentage.toFixed(2),
                severity: aiWarning.severity
            };
        });

        // Sort by attendance percentage
        stats.sort((a, b) => parseFloat(a.attendancePercentage) - parseFloat(b.attendancePercentage));

        const criticalStudents = stats.filter(s => parseFloat(s.attendancePercentage) < 75);

        res.json({
            success: true,
            totalStudents: students.length,
            criticalCount: criticalStudents.length,
            data: stats,
            criticalStudents
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching attendance statistics',
            error: error.message
        });
    }
});

module.exports = router;

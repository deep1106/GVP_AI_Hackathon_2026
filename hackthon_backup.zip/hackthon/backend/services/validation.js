// Input validation and sanitization utilities

/**
 * Sanitize string input to prevent XSS attacks
 */
function sanitizeString(input) {
    if (typeof input !== 'string') return input;

    return input
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#x27;')
        .replace(/\//g, '&#x2F;')
        .trim();
}

/**
 * Validate student data
 */
function validateStudent(data) {
    const errors = [];

    // Validate name
    if (!data.name || data.name.trim().length === 0) {
        errors.push('Name is required');
    } else if (data.name.length < 2) {
        errors.push('Name must be at least 2 characters long');
    } else if (data.name.length > 100) {
        errors.push('Name must not exceed 100 characters');
    } else if (!/^[a-zA-Z\s.'-]+$/.test(data.name)) {
        errors.push('Name contains invalid characters');
    }

    // Validate roll number
    if (!data.rollNumber || data.rollNumber.trim().length === 0) {
        errors.push('Roll number is required');
    } else if (!/^[A-Z0-9-]+$/i.test(data.rollNumber)) {
        errors.push('Roll number can only contain letters, numbers, and hyphens');
    } else if (data.rollNumber.length > 20) {
        errors.push('Roll number must not exceed 20 characters');
    }

    // Validate email if provided
    if (data.email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(data.email)) {
            errors.push('Invalid email format');
        }
    }

    // Validate class/grade if provided
    if (data.class && (data.class.length > 50)) {
        errors.push('Class name must not exceed 50 characters');
    }

    return {
        isValid: errors.length === 0,
        errors
    };
}

/**
 * Validate attendance data
 */
function validateAttendance(data) {
    const errors = [];

    // Validate student ID
    if (!data.studentId || isNaN(parseInt(data.studentId))) {
        errors.push('Valid student ID is required');
    }

    // Validate date
    if (!data.date) {
        errors.push('Date is required');
    } else {
        const dateObj = new Date(data.date);
        if (isNaN(dateObj.getTime())) {
            errors.push('Invalid date format');
        }
    }

    // Validate status
    const validStatuses = ['present', 'absent', 'late', 'excused'];
    if (!data.status || !validStatuses.includes(data.status.toLowerCase())) {
        errors.push('Status must be one of: present, absent, late, excused');
    }

    return {
        isValid: errors.length === 0,
        errors
    };
}

/**
 * Validate performance data
 */
function validatePerformance(data) {
    const errors = [];

    // Validate student ID
    if (!data.studentId || isNaN(parseInt(data.studentId))) {
        errors.push('Valid student ID is required');
    }

    // Validate subject
    if (!data.subject || data.subject.trim().length === 0) {
        errors.push('Subject is required');
    } else if (data.subject.length > 100) {
        errors.push('Subject name must not exceed 100 characters');
    }

    // Validate marks
    if (data.marks === undefined || data.marks === null) {
        errors.push('Marks are required');
    } else {
        const marks = parseFloat(data.marks);
        if (isNaN(marks)) {
            errors.push('Marks must be a valid number');
        } else if (marks < 0 || marks > 100) {
            errors.push('Marks must be between 0 and 100');
        }
    }

    // Validate max marks if provided
    if (data.maxMarks !== undefined) {
        const maxMarks = parseFloat(data.maxMarks);
        if (isNaN(maxMarks) || maxMarks <= 0) {
            errors.push('Max marks must be a positive number');
        }
    }

    return {
        isValid: errors.length === 0,
        errors
    };
}

/**
 * Sanitize object recursively
 */
function sanitizeObject(obj) {
    if (typeof obj !== 'object' || obj === null) {
        return obj;
    }

    const sanitized = {};
    for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
            if (typeof obj[key] === 'string') {
                sanitized[key] = sanitizeString(obj[key]);
            } else if (typeof obj[key] === 'object') {
                sanitized[key] = sanitizeObject(obj[key]);
            } else {
                sanitized[key] = obj[key];
            }
        }
    }
    return sanitized;
}

module.exports = {
    sanitizeString,
    sanitizeObject,
    validateStudent,
    validateAttendance,
    validatePerformance
};

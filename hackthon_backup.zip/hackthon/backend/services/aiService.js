// AI Service - Intelligent assistance for attendance and performance tracking

/**
 * Generate intelligent performance remarks based on marks
 * This AI-like system uses contextual analysis to provide meaningful feedback
 */
function generatePerformanceRemarks(marks, maxMarks = 100, subject = '') {
    const percentage = (marks / maxMarks) * 100;

    // AI-driven remark generation based on performance tiers
    let remark = '';
    let category = '';
    let suggestions = [];

    if (percentage >= 90) {
        category = 'Excellent';
        const excellentRemarks = [
            `Outstanding performance in ${subject}! Keep up the exceptional work.`,
            `Exemplary achievement! Your dedication to ${subject} is truly commendable.`,
            `Brilliant work! You've mastered the concepts in ${subject} exceptionally well.`,
            `Exceptional performance! Continue this excellent trajectory in ${subject}.`
        ];
        remark = excellentRemarks[Math.floor(Math.random() * excellentRemarks.length)];
        suggestions = [
            'Consider mentoring peers who need help',
            'Explore advanced topics in this subject',
            'Participate in competitions or olympiads'
        ];
    } else if (percentage >= 75) {
        category = 'Good';
        const goodRemarks = [
            `Very good performance in ${subject}. With a bit more effort, you can achieve excellence.`,
            `Strong understanding demonstrated in ${subject}. Keep pushing for higher goals.`,
            `Commendable work in ${subject}! You're on the right track.`,
            `Good grasp of ${subject} concepts. Consistent effort will lead to mastery.`
        ];
        remark = goodRemarks[Math.floor(Math.random() * goodRemarks.length)];
        suggestions = [
            'Review challenging topics regularly',
            'Practice more problem-solving exercises',
            'Seek clarification on difficult concepts'
        ];
    } else if (percentage >= 60) {
        category = 'Average';
        const averageRemarks = [
            `Satisfactory performance in ${subject}. Focus on strengthening your fundamentals.`,
            `Average performance in ${subject}. More consistent study habits will help improve.`,
            `Decent effort in ${subject}. Identify weak areas and work on them systematically.`,
            `Fair performance in ${subject}. Regular practice can significantly boost your scores.`
        ];
        remark = averageRemarks[Math.floor(Math.random() * averageRemarks.length)];
        suggestions = [
            'Create a structured study schedule',
            'Focus on understanding core concepts',
            'Attend extra help sessions if available',
            'Form study groups with peers'
        ];
    } else if (percentage >= 40) {
        category = 'Needs Improvement';
        const needsImprovementRemarks = [
            `${subject} requires more attention. Let's work together to improve your understanding.`,
            `Performance in ${subject} needs improvement. Don't hesitate to ask for help.`,
            `${subject} is challenging, but with focused effort, you can improve significantly.`,
            `More dedication needed in ${subject}. Identify your weak points and address them.`
        ];
        remark = needsImprovementRemarks[Math.floor(Math.random() * needsImprovementRemarks.length)];
        suggestions = [
            'Schedule one-on-one sessions with teacher',
            'Start with basics and build gradually',
            'Use additional learning resources',
            'Practice daily, even if just for 30 minutes',
            'Break down complex topics into smaller parts'
        ];
    } else {
        category = 'Critical - Immediate Attention Required';
        const criticalRemarks = [
            `${subject} needs immediate attention. Please meet with your teacher to create an improvement plan.`,
            `Urgent: ${subject} performance is concerning. Let's develop a personalized learning strategy.`,
            `Critical situation in ${subject}. Immediate intervention and support are necessary.`,
            `${subject} requires intensive focus. Don't worry - with the right support, improvement is possible.`
        ];
        remark = criticalRemarks[Math.floor(Math.random() * criticalRemarks.length)];
        suggestions = [
            'Immediate teacher consultation required',
            'Consider tutoring or remedial classes',
            'Identify if there are any learning barriers',
            'Create a detailed recovery plan',
            'Regular progress monitoring needed',
            'Parent-teacher meeting recommended'
        ];
    }

    return {
        remark,
        category,
        percentage: percentage.toFixed(2),
        suggestions,
        aiGenerated: true,
        timestamp: new Date().toISOString()
    };
}

/**
 * Generate attendance warnings and suggestions
 * AI analyzes attendance patterns and provides actionable insights
 */
function generateAttendanceWarning(attendancePercentage, studentName = 'Student') {
    const warnings = [];
    const suggestions = [];
    let severity = 'normal';
    let message = '';

    if (attendancePercentage < 75) {
        severity = 'critical';
        message = `⚠️ CRITICAL: ${studentName}'s attendance is ${attendancePercentage.toFixed(1)}% - Below the 75% minimum requirement!`;
        warnings.push('Attendance below minimum threshold');
        warnings.push('May affect academic eligibility');
        warnings.push('Immediate action required');

        suggestions.push('Schedule meeting with student and parents');
        suggestions.push('Identify reasons for absences');
        suggestions.push('Create attendance improvement plan');
        suggestions.push('Monitor daily attendance closely');
        suggestions.push('Consider medical or personal circumstances');
    } else if (attendancePercentage < 80) {
        severity = 'warning';
        message = `⚠️ WARNING: ${studentName}'s attendance is ${attendancePercentage.toFixed(1)}% - Approaching minimum threshold`;
        warnings.push('Attendance approaching critical level');
        warnings.push('Risk of falling below 75%');

        suggestions.push('Remind student about attendance importance');
        suggestions.push('Monitor attendance weekly');
        suggestions.push('Encourage consistent attendance');
    } else if (attendancePercentage < 90) {
        severity = 'caution';
        message = `ℹ️ NOTICE: ${studentName}'s attendance is ${attendancePercentage.toFixed(1)}% - Room for improvement`;
        suggestions.push('Encourage better attendance');
        suggestions.push('Recognize improvement efforts');
    } else {
        severity = 'good';
        message = `✅ EXCELLENT: ${studentName}'s attendance is ${attendancePercentage.toFixed(1)}% - Keep it up!`;
        suggestions.push('Maintain current attendance pattern');
        suggestions.push('Great commitment to learning');
    }

    return {
        message,
        severity,
        percentage: attendancePercentage.toFixed(2),
        warnings,
        suggestions,
        aiGenerated: true,
        timestamp: new Date().toISOString()
    };
}

/**
 * Validate student data with AI-powered suggestions
 * Provides intelligent error messages and recommendations
 */
function validateWithAI(data, type) {
    const insights = {
        isValid: true,
        errors: [],
        suggestions: [],
        aiInsights: []
    };

    if (type === 'student') {
        // AI-powered name validation
        if (data.name && data.name.length < 3) {
            insights.aiInsights.push('Short names might be nicknames. Consider using full name for official records.');
        }

        // AI-powered roll number pattern detection
        if (data.rollNumber) {
            const hasYear = /20\d{2}/.test(data.rollNumber);
            const hasClass = /\d{1,2}[A-Z]/.test(data.rollNumber);

            if (!hasYear && !hasClass) {
                insights.suggestions.push('Consider including year or class in roll number for better organization (e.g., 2024-10A-001)');
            }
        }
    }

    if (type === 'performance') {
        // AI detects unusual mark patterns
        if (data.marks !== undefined) {
            const marks = parseFloat(data.marks);
            if (marks === 0) {
                insights.aiInsights.push('Zero marks detected. Verify if this is correct or if student was absent.');
            } else if (marks === 100) {
                insights.aiInsights.push('Perfect score! Consider recognizing this achievement.');
            } else if (marks < 40) {
                insights.aiInsights.push('Low score detected. Consider offering additional support or remedial sessions.');
            }
        }
    }

    return insights;
}

/**
 * Generate sample student data for testing
 * AI creates realistic, diverse student profiles
 */
function generateSampleStudents(count = 5) {
    const firstNames = ['Aarav', 'Vivaan', 'Aditya', 'Arjun', 'Sai', 'Ananya', 'Diya', 'Isha', 'Priya', 'Riya'];
    const lastNames = ['Sharma', 'Patel', 'Kumar', 'Singh', 'Reddy', 'Nair', 'Gupta', 'Mehta', 'Joshi', 'Rao'];
    const classes = ['10A', '10B', '11A', '11B', '12A', '12B'];

    const students = [];
    const currentYear = new Date().getFullYear();

    for (let i = 0; i < count; i++) {
        const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
        const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
        const classSection = classes[Math.floor(Math.random() * classes.length)];

        students.push({
            name: `${firstName} ${lastName}`,
            rollNumber: `${currentYear}-${classSection}-${String(i + 1).padStart(3, '0')}`,
            class: classSection,
            email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}@school.edu`
        });
    }

    return students;
}

/**
 * Analyze overall class performance
 * AI provides insights on class trends
 */
function analyzeClassPerformance(performanceRecords) {
    if (performanceRecords.length === 0) {
        return {
            message: 'No performance data available for analysis',
            insights: []
        };
    }

    const marks = performanceRecords.map(p => parseFloat(p.marks));
    const average = marks.reduce((a, b) => a + b, 0) / marks.length;
    const highest = Math.max(...marks);
    const lowest = Math.min(...marks);

    const excellent = marks.filter(m => m >= 90).length;
    const good = marks.filter(m => m >= 75 && m < 90).length;
    const average_count = marks.filter(m => m >= 60 && m < 75).length;
    const needsImprovement = marks.filter(m => m < 60).length;

    const insights = [];

    if (average >= 75) {
        insights.push('Overall class performance is strong');
    } else if (average >= 60) {
        insights.push('Class performance is satisfactory but has room for improvement');
    } else {
        insights.push('Class performance needs attention - consider reviewing teaching methods');
    }

    if (needsImprovement > performanceRecords.length * 0.3) {
        insights.push(`${needsImprovement} students need additional support`);
    }

    if (excellent > 0) {
        insights.push(`${excellent} students showing excellent performance`);
    }

    return {
        average: average.toFixed(2),
        highest,
        lowest,
        distribution: {
            excellent,
            good,
            average: average_count,
            needsImprovement
        },
        insights,
        aiGenerated: true
    };
}

module.exports = {
    generatePerformanceRemarks,
    generateAttendanceWarning,
    validateWithAI,
    generateSampleStudents,
    analyzeClassPerformance
};
